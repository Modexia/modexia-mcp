import os
from dotenv import load_dotenv
from mcp.server.fastmcp import FastMCP
from pydantic import BaseModel
from typing import Optional
import sys

# We suppress import errors in case modexiaagentpay isn't fully installed yet.
try:
    from modexia import ModexiaClient, ModexiaPaymentError
except ImportError:
    ModexiaClient = None
    ModexiaPaymentError = None

load_dotenv()

# We set up a FastMCP instance. FastMCP automatically creates tools/resources/prompts via decorators
mcp_server = FastMCP(
    "ModexiaAgentpay",
    dependencies=["modexiaagentpay", "python-dotenv"]
)

def get_modexia_client():
    if ModexiaClient is None:
        raise RuntimeError("modexiaagentpay is not installed properly.")
        
    api_key = os.getenv("MODEXIA_API_KEY")
    base_url = os.getenv("MODEXIA_BASE_URL", "https://sandbox.modexia.software")
    if not api_key:
        raise ValueError("MODEXIA_API_KEY environment variable is missing. It must be provided (e.g. mx_test_...).")
    
    import sys
    print(f"🪲 [DEBUG] Running tool using base_url: {base_url}", file=sys.stderr)
    
    # We pass base_url explicitly in case python-dotenv missed it or it wasn't exported globally
    return ModexiaClient(api_key=api_key, base_url=base_url)

# -----------------
# TOOLS
# -----------------
@mcp_server.tool()
def get_balance() -> str:
    """Retrieve the current USDC wallet balance for the Agent's Smart Contract Wallet."""
    client = get_modexia_client()
    return client.retrieve_balance()

@mcp_server.tool()
def transfer(recipient: str, amount: float, idempotency_key: Optional[str] = None, memo: Optional[str] = None) -> dict:
    """
    Send a standard Modexia payment (USDC) to a recipient.
    Recommended to always provide an idempotency_key to prevent double charges.
    Optionally provide a memo to explain the reason for the payment (visible in audit trail).
    """
    client = get_modexia_client()
    
    try:
        receipt = client.transfer(recipient, amount, wait=True, idempotency_key=idempotency_key, memo=memo)
        
        return {
            "success": receipt.success,
            "txId": getattr(receipt, "txId", None),
            "status": getattr(receipt, "status", "COMPLETE"),
            "txHash": getattr(receipt, "txHash", None),
            "errorReason": getattr(receipt, "errorReason", None)
        }
    except TimeoutError as e:
        # Blockchain took longer than 30s, but it was submitted
        return {
            "success": True,
            "status": "PENDING",
            "message": "Transaction submitted successfully but is taking longer than usual to settle on the blockchain.",
            "errorReason": str(e)
        }

@mcp_server.tool()
def cross_chain_transfer(to_chain: str, to_token: str, recipient: str, amount: float, idempotency_key: Optional[str] = None) -> dict:
    """
    Send a cross-chain CCTP payment natively to another blockchain using Squid Router.
    Requires `to_chain` (e.g., '1' for Ethereum, 'akashnet-2' for Akash Network), `to_token` address, 
    and the `recipient` wallet address. Gas relaying on the destination is covered automatically!
    Always provide an idempotency_key to prevent double charges.
    """
    client = get_modexia_client()
    
    receipt = client.cross_chain_transfer(to_chain, to_token, recipient, amount, idempotency_key=idempotency_key)
    
    return {
        "success": getattr(receipt, "success", False),
        "txId": getattr(receipt, "txId", None),
        "status": getattr(receipt, "status", "PENDING"),
        "errorReason": getattr(receipt, "errorReason", None)
    }

@mcp_server.tool()
def get_history(limit: int = 5) -> dict:
    """Fetch the recent transaction history for the authenticated agent."""
    client = get_modexia_client()
    resp = client.get_history(limit=limit)
    return {
        "transactions": [
            {
                "txId": getattr(t, "txId", ""), 
                "amount": getattr(t, "amount", ""), 
                "state": getattr(t, "state", ""), 
                "providerAddress": getattr(t, "providerAddress", ""),
                "memo": getattr(t, "memo", None),
            }
            for t in resp.transactions
        ],
        "hasMore": getattr(resp, "hasMore", False)
    }

@mcp_server.tool()
def open_channel(provider: str, deposit_amount: float, duration_hours: float = 24.0) -> dict:
    """
    Open a high-frequency micro-payment vault channel with on-chain deposit.
    Blocks funds for the specific provider, allowing instant, gas-free payments via `consume_channel`.
    """
    client = get_modexia_client()
    return client.open_channel(provider, deposit_amount, duration_hours)

@mcp_server.tool()
def consume_channel(channel_id: str, amount: float, idempotency_key: Optional[str] = None) -> dict:
    """
    Execute an instant, gas-free micro-payment inside an already open channel.
    Call this as many times as needed while the channel is open.
    """
    client = get_modexia_client()
    res = client.consume_channel(channel_id, amount, idempotency_key=idempotency_key)
    return {
        "success": getattr(res, "success", False),
        "remaining": getattr(res, "remaining", "0"),
        "isDuplicate": getattr(res, "isDuplicate", False)
    }

@mcp_server.tool()
def settle_channel(channel_id: str) -> dict:
    """Settle an open micro-payment channel, paying the provider, and refunding the remainder back to you."""
    client = get_modexia_client()
    return client.settle_channel(channel_id)

@mcp_server.tool()
def get_channel(channel_id: str) -> dict:
    """Get the current status, deposit amount, and remaining balance of a specific payment channel."""
    client = get_modexia_client()
    status = client.get_channel(channel_id)
    return {
        "channelId": getattr(status, "channelId", channel_id),
        "providerAddress": getattr(status, "providerAddress", ""),
        "deposit": getattr(status, "deposit", "0"),
        "remaining": getattr(status, "remaining", "0"),
        "state": getattr(status, "state", ""),
        "isExpired": getattr(status, "isExpired", False)
    }

@mcp_server.tool()
def list_channels(limit: int = 50) -> dict:
    """List all payment channels associated with the authenticated agent's wallet."""
    client = get_modexia_client()
    channels = client.list_channels(limit=limit)
    return {
        "channels": [
            {
                "channelId": getattr(c, "channelId", ""),
                "providerAddress": getattr(c, "providerAddress", ""),
                "deposit": getattr(c, "deposit", "0"),
                "remaining": getattr(c, "remaining", "0"),
                "state": getattr(c, "state", "")
            } for c in channels
        ]
    }

@mcp_server.tool()
def smart_fetch(method: str, url: str) -> dict:
    """
    Fetch an external resource via HTTP. If the resource responds with a 402 Payment Required
    and a WWW-Authenticate header, this tool will automatically negotiate and pay the invoice 
    via Modexia AgentPay, then retry the request with the cryptographic proof of payment.
    """
    client = get_modexia_client()
    resp = client.smart_fetch(method, url)
    try:
        data = resp.json()
    except Exception:
        data = resp.text[:2000] # truncate pure text
    
    return {
        "status_code": resp.status_code,
        "data": data
    }

# -----------------
# RESOURCES
# -----------------
@mcp_server.resource("modexia://docs/llms_context")
def get_modexia_context() -> str:
    """
    Retrieve the comprehensive Modexia developer guide, containing rules on 
    how AI agents should execute payments, open channels, and handle 402 Paywalls.
    Always read this before performing complex financial operations on Modexia.
    """
    # Load the bundled context file relative to this module
    file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "modexia_context.md")
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            return f.read()
    except Exception as e:
        return f"Error reading Modexia context: {str(e)}"

# -----------------
# PROMPTS
# -----------------
@mcp_server.prompt()
def create_payment_instruction() -> str:
    """Provides internal guidelines to an agent on how to correctly structure a standard payment with Modexia."""
    file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "prompts", "create_payment_instruction.md")
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            return f.read()
    except Exception:
        return ""

@mcp_server.prompt()
def setup_microtransactions_instruction() -> str:
    """Provides internal guidelines to an agent on how to securely open and use a micro-payment channel."""
    file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "prompts", "setup_microtransactions_instruction.md")
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            return f.read()
    except Exception:
        return ""

@mcp_server.tool()
def submit_intent(recipient: str, amount: float, memo: Optional[str] = None) -> dict:
    """
    Submit an intent-based payment (v2 API). Creates a signed intent token, 
    submits it through the validation pipeline, and returns a rich result with 
    compliance metadata (policy limits, daily spend, balance). 
    Always provide a memo describing why you are making this payment.
    """
    client = get_modexia_client()
    result = client.pay(recipient, amount, memo=memo, wait=True)
    return {
        "status": result.status,
        "intent_id": result.intent_id,
        "txId": result.txId,
        "amount": result.amount,
        "recipient": result.recipient,
        "wallet_balance_after": result.wallet_balance_after,
        "daily_spent": result.daily_spent,
        "daily_remaining": result.daily_remaining,
        "reason": result.reason,
        "code": result.code,
        "suggestion": result.suggestion,
        "validation": result.validation,
    }

@mcp_server.tool()
def get_intent(intent_id: str) -> dict:
    """Get the status and details of a previously submitted payment intent."""
    client = get_modexia_client()
    result = client.get_intent(intent_id)
    return {
        "status": result.status,
        "intent_id": result.intent_id,
        "txId": result.txId,
        "amount": result.amount,
        "recipient": result.recipient,
        "reason": result.reason,
        "code": result.code,
        "validation": result.validation,
    }

@mcp_server.tool()
def list_intents(limit: int = 10) -> dict:
    """List the most recent payment intents with their status and details."""
    client = get_modexia_client()
    intents = client.list_intents(limit=limit)
    return {
        "intents": [
            {
                "intent_id": i.intent_id,
                "status": i.status,
                "amount": i.amount,
                "recipient": i.recipient,
                "txId": i.txId,
                "code": i.code,
            }
            for i in intents
        ]
    }

@mcp_server.prompt()
def create_intent_payment_instruction() -> str:
    """Provides guidelines to an agent on how to use the intent-based payment system (v2)."""
    file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "prompts", "create_intent_payment_instruction.md")
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            return f.read()
    except Exception:
        return ""


# ═══════════════════════════════════════════════════════════════════
#  NANOPAY — Circle Gateway Nanopayments (x402)
# ═══════════════════════════════════════════════════════════════════

@mcp_server.tool()
def nanopay(url: str, method: str = "GET") -> dict:
    """
    Fetch an x402-protected resource and automatically pay using Circle Gateway
    nanopayments. Gas-free, instant, supports payments as low as $0.000001 USDC.
    Use this for sub-cent API calls and premium data purchases.
    """
    client = get_modexia_client()
    try:
        result = client.nanopay(url, method)
        return {
            "success": result.success,
            "status_code": result.status_code,
            "data": result.data,
            "amount_paid": result.amount_paid,
            "signature": getattr(result, "signature", None),
        }
    except ModexiaPaymentError as e:
        return {
            "success": False,
            "error": str(e),
            "code": getattr(e, "code", None),
            "details": getattr(e, "details", {}),
        }

@mcp_server.tool()
def nanopay_balance() -> dict:
    """Get the agent's Circle Gateway nanopayment balance (separate from main wallet balance)."""
    client = get_modexia_client()
    balance = client.nanopay_balance()
    return {
        "available": balance.available,
        "total": balance.total,
        "withdrawing": balance.withdrawing,
        "auto_refill_enabled": balance.auto_refill_enabled,
    }

@mcp_server.tool()
def nanopay_deposit(amount: float) -> dict:
    """
    Deposit USDC from the agent's main wallet into the nanopayment Gateway.
    This is an on-chain transaction. After depositing, nanopayments are gas-free.
    """
    client = get_modexia_client()
    result = client.nanopay_deposit(amount)
    return {
        "success": result.success,
        "deposit_tx_id": result.deposit_tx_id,
        "amount": result.amount,
    }

@mcp_server.tool()
def nanopay_withdraw(amount: float) -> dict:
    """Withdraw USDC from the nanopayment Gateway back to the agent's main wallet."""
    client = get_modexia_client()
    result = client.nanopay_withdraw(amount)
    return {
        "success": result.success,
        "withdraw_tx_id": result.withdraw_tx_id,
        "amount": result.amount,
    }

@mcp_server.tool()
def nanopay_activate() -> dict:
    """
    Enable Circle Gateway nanopayments for this agent.
    Must be called once before using nanopay, nanopay_deposit, or nanopay_balance.
    Idempotent — calling again returns the existing activation.
    """
    client = get_modexia_client()
    return client.nanopay_activate()

@mcp_server.prompt()
def nanopay_usage_instruction() -> str:
    """Provides guidelines on how to use Circle Gateway nanopayments."""
    file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "prompts", "nanopay_usage_instruction.md")
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            return f.read()
    except Exception:
        return ""


def main():
    import sys
    import os
    port = os.getenv("PORT")

    if port:
        print(f"🚀 Starting Modexia MCP Server on SSE transport (Port {port})...", file=sys.stderr)
        mcp_server.run(transport='sse', host='0.0.0.0', port=int(port))
    else:
        print("🚀 Modexia MCP Server is running locally on stdio transport and waiting for connections...", file=sys.stderr)
        mcp_server.run(transport='stdio')

if __name__ == "__main__":
    main()
